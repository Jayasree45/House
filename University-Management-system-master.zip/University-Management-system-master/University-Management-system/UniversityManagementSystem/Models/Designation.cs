﻿namespace UniversityManagementSystem.Models
{
    public class Designation
    {
        public int Id { set; get; }
        public string Title { get; set; }
    }
}
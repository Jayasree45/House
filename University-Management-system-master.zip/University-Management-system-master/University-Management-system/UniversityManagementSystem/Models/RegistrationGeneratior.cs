﻿namespace UniversityManagementSystem.Models
{
    public static class RegistrationGeneratior
    {
        
        public static string GenerateRegistration(int id)
        {

            return null;
        }
    }
}
﻿namespace UniversityManagementSystem.Models
{
    public class StudentResultViewModel
    {
        public int StudentId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Grade { get; set; }

    }
}
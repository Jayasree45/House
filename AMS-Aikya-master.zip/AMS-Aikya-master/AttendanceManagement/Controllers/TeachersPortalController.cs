﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AttendanceManagement.Controllers
{
    public class TeachersPortalController : Controller
    {
        // GET: TeachersPortal
        public ActionResult Index()
        {
            return View();
        }
    }
}